// worker/src/services/menus.js
/**
 * ═══════════════════════════════════════════════════════════════
 * KAAPAV Menu Service
 * Sends interactive WhatsApp menus (matching sendMessage.js)
 * ═══════════════════════════════════════════════════════════════
 */

import { WhatsAppService } from './whatsapp';
import { getConfig } from '../config';

export class MenuService {
  constructor(env) {
    this.env = env;
    this.wa = new WhatsAppService(env);
    this.config = getConfig(env);
    this.links = this.config.links;
  }

  /**
   * Simple translation helper (placeholder for future i18n)
   * In production, integrate with Google Translate or similar
   */
  async t(text, lang = 'en') {
    // TODO: Add actual translation service
    // For now, return English text
    return text;
  }

  // ═══════════════════════════════════════════════════════════════
  // MAIN MENU
  // ═══════════════════════════════════════════════════════════════

  async sendMainMenu(phone, lang = 'en') {
    const body = await this.t(
      "✨ Welcome to *KAAPAV Luxury Jewellery*! ✨\n\n" +
      "👑 Crafted Elegance • Timeless Sparkle 💎\n" +
      "Choose an option below 👇",
      lang
    );

    const footer = await this.t("💖 Luxury Meets You, Only at KAAPAV", lang);

    const buttons = [
      { id: 'JEWELLERY_MENU', title: '💎 Jewellery' },
      { id: 'CHAT_MENU', title: '💬 Chat with Us!' },
      { id: 'OFFERS_MENU', title: '🎉 Offers & More' },
    ];

    return this.wa.sendButtons(phone, body, buttons, footer);
  }

  // ═══════════════════════════════════════════════════════════════
  // JEWELLERY MENU
  // ═══════════════════════════════════════════════════════════════

  async sendJewelleryMenu(phone, lang = 'en') {
    const body = await this.t(
      "💎 *Explore KAAPAV Collections* 💎\n\n" +
      "✨ Handcrafted designs, curated for royalty 👑",
      lang
    );

    const footer = await this.t("🌐 kaapav.com | 📱 Catalogue", lang);

    const buttons = [
      { id: 'OPEN_WEBSITE', title: '🌐 Website' },
      { id: 'OPEN_CATALOG', title: '📱 Catalogue' },
      { id: 'MAIN_MENU', title: '🏠 Home' },
    ];

    return this.wa.sendButtons(phone, body, buttons, footer);
  }

  // ═══════════════════════════════════════════════════════════════
  // OFFERS MENU
  // ═══════════════════════════════════════════════════════════════

  async sendOffersMenu(phone, lang = 'en') {
    const body = await this.t(
      "💫 *Exclusive Luxury Offers!* 💫\n\n" +
      "🎉 Flat 50% OFF Select Styles ✨\n" +
      "🚚 Free Shipping Above ₹498/- 💝",
      lang
    );

    const footer = await this.t("🛍️ KAAPAV Bestsellers", lang);

    const buttons = [
      { id: 'OPEN_BESTSELLERS', title: '🛍️ Bestsellers' },
      { id: 'PAYMENT_MENU', title: '💳 Payment & Track' },
      { id: 'MAIN_MENU', title: '🏠 Home' },
    ];

    return this.wa.sendButtons(phone, body, buttons, footer);
  }

  // ═══════════════════════════════════════════════════════════════
  // PAYMENT MENU
  // ═══════════════════════════════════════════════════════════════

  async sendPaymentMenu(phone, lang = 'en') {
    const body = await this.t(
      "💎 *Complete Your Sparkle with KAAPAV* 💎\n\n" +
      "Choose a secure option:\n" +
      "1️⃣ 💳 Payment – UPI or Cards\n" +
      "2️⃣ 📦 Track Your Order – Shiprocket\n\n" +
      "🚫 No COD ❌",
      lang
    );

    const footer = await this.t("👑 KAAPAV – Luxury, Seamless & Secure ✨", lang);

    const buttons = [
      { id: 'PAY_NOW', title: '💳 Payment' },
      { id: 'TRACK_ORDER', title: '📦 Track Order' },
      { id: 'MAIN_MENU', title: '🏠 Home' },
    ];

    return this.wa.sendButtons(phone, body, buttons, footer);
  }

  // ═══════════════════════════════════════════════════════════════
  // CHAT MENU
  // ═══════════════════════════════════════════════════════════════

  async sendChatMenu(phone, lang = 'en') {
    const body = await this.t(
      "💬 *Need Help? We're Here for You!* 💬\n\n" +
      "Please describe your query below ⬇️\n" +
      "Our support team will assist you with luxury care 👑✨",
      lang
    );

    const footer = await this.t("We are just a tap away 💖", lang);

    const buttons = [
      { id: 'CHAT_NOW', title: '💬 Chat Now' },
      { id: 'SOCIAL_MENU', title: '🌐 FB & Instagram' },
      { id: 'MAIN_MENU', title: '🏠 Home' },
    ];

    return this.wa.sendButtons(phone, body, buttons, footer);
  }

  // ═══════════════════════════════════════════════════════════════
  // SOCIAL MENU
  // ═══════════════════════════════════════════════════════════════

  async sendSocialMenu(phone, lang = 'en') {
    const body = await this.t(
      "🌐 *Follow KAAPAV on Social Media* 🌐\n\n" +
      "Stay connected for luxury vibes 👑✨",
      lang
    );

    const footer = await this.t("📲 Choose your platform below 👇", lang);

    const buttons = [
      { id: 'OPEN_FACEBOOK', title: '📘 Facebook' },
      { id: 'OPEN_INSTAGRAM', title: '📸 Instagram' },
      { id: 'MAIN_MENU', title: '🏠 Home' },
    ];

    return this.wa.sendButtons(phone, body, buttons, footer);
  }

  // ═══════════════════════════════════════════════════════════════
  // LINK SENDER (for CTAs)
  // ═══════════════════════════════════════════════════════════════

  async sendLink(phone, action, lang = 'en') {
    const linkMessages = {
      'OPEN_WEBSITE': {
        emoji: '🌐',
        text: 'Browse our website:',
        url: this.links.website,
      },
      'OPEN_CATALOG': {
        emoji: '📱',
        text: 'WhatsApp Catalogue:',
        url: this.links.whatsappCatalog,
      },
      'OPEN_BESTSELLERS': {
        emoji: '🛍️',
        text: 'Shop Bestsellers:',
        url: this.links.offersBestsellers,
      },
      'PAY_NOW': {
        emoji: '💳',
        text: 'Pay via UPI/Card/Netbanking:',
        url: this.links.payment,
      },
      'TRACK_ORDER': {
        emoji: '📦',
        text: 'Track your order:',
        url: this.links.shiprocket,
      },
      'CHAT_NOW': {
        emoji: '💬',
        text: 'Chat with us:',
        url: this.links.waMeChat,
      },
      'OPEN_FACEBOOK': {
        emoji: '📘',
        text: 'Facebook:',
        url: this.links.facebook,
      },
      'OPEN_INSTAGRAM': {
        emoji: '📸',
        text: 'Instagram:',
        url: this.links.instagram,
      },
    };

    const link = linkMessages[action];
    if (!link) {
      console.warn(`Unknown link action: ${action}`);
      return this.sendMainMenu(phone, lang);
    }

    const message = `${link.emoji} ${await this.t(link.text, lang)}\n${link.url}`;
    return this.wa.sendText(phone, message);
  }
}

export default MenuService;
